﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Simulacion
{
    public partial class SimulacionPrestamos : Form
    {
        public SimulacionPrestamos()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                decimal monto = decimal.Parse(txtMonto.Text);
                decimal interesAnual = decimal.Parse(txtInteres.Text) / 100;
                int meses = int.Parse(txtMeses.Text);

                string tipo = cmbTipoInteres.SelectedItem.ToString();
                decimal totalPagar = 0;
                decimal cuotaMensual = 0;

                switch (tipo)
                {
                    case "Simple":
                        decimal interesSimple = monto * interesAnual * (meses / 12m);
                        totalPagar = monto + interesSimple;
                        cuotaMensual = totalPagar / meses;
                        break;

                    case "Compuesto":
                        totalPagar = monto * (decimal)Math.Pow((double)(1 + interesAnual / 12), meses);
                        cuotaMensual = totalPagar / meses;
                        break;

                    case "Amortizable":
                        decimal tasaMensual = interesAnual / 12;
                        cuotaMensual = monto * (tasaMensual / (1 - (decimal)Math.Pow(1 + (double)tasaMensual, -meses)));
                        totalPagar = cuotaMensual * meses;
                        break;
                }

                lblTotal.Text = $"Total a pagar: {totalPagar:C}";
                Listadoprestamo.Items.Clear();

                DateTime fechaInicio = DateTime.Now;

                for (int i = 1; i <= meses; i++)
                {
                    DateTime fechaPago = fechaInicio.AddMonths(i);
                    Listadoprestamo.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota: {cuotaMensual:C}");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingresa valores numéricos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }


        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                decimal monto = decimal.Parse(txtMonto.Text);
                decimal interesAnual = decimal.Parse(txtInteres.Text);
                int meses = int.Parse(txtMeses.Text);
                string tipo = cmbTipoInteres.SelectedItem.ToString();

                decimal totalInteres = monto * (interesAnual / 100) * (meses / 12m);
                decimal totalPagar = monto + totalInteres;

                string contenido = $"Cotización de préstamo:\r\n" +
                                  $"Monto solicitado: {monto:C}\r\n" +
                                  $"Interés anual: {interesAnual}%\r\n" +
                                  $"Tipo de interés: {tipo}\r\n" +
                                  $"Plazo (meses): {meses}\r\n" +
                                  $"Total a pagar: {totalPagar:C}\r\n" +
                                  $"Fecha: {DateTime.Now}\r\n" +
                                  $"---------------------------\r\n";

                string rutaArchivo = "CotizacionesPrestamos.txt";

                File.AppendAllText(rutaArchivo, contenido);

                MessageBox.Show("Cotización guardada en archivo.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingresa valores numéricos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}");
            }
        }

        private void SimulacionPrestamos_Load(object sender, EventArgs e)
        {

        }

        private void lblCliente_Click(object sender, EventArgs e)
        {

        }
    }
}
