﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Simulacion
{
    public partial class SimulacionPrestamos : Form
    {
        public SimulacionPrestamos()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                decimal monto = decimal.Parse(txtMonto.Text);
                decimal interesAnual = decimal.Parse(txtInteres.Text) / 100;
                int meses = int.Parse(txtMeses.Text);

                decimal totalInteres = monto * interesAnual * (meses / 12m);
                decimal totalPagar = monto + totalInteres;

                lblTotal.Text = $"Total a pagar: {totalPagar:C}";
                Listadoprestamo.Items.Clear();

                decimal cuotaMensual = totalPagar / meses;

                DateTime fechaInicio = DateTime.Now;

                for (int i = 1; i <= meses; i++)
                {
                    DateTime fechaPago = fechaInicio.AddMonths(i);
                    Listadoprestamo.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota: {cuotaMensual:C}");
                }

            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingresa valores numéricos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                decimal monto = decimal.Parse(txtMonto.Text);
                decimal interesAnual = decimal.Parse(txtInteres.Text);
                int meses = int.Parse(txtMeses.Text);

                decimal totalInteres = monto * (interesAnual / 100) * (meses / 12m);
                decimal totalPagar = monto + totalInteres;

                string contenido = $"Cotización de préstamo:\r\n" +
                                  $"Monto solicitado: {monto:C}\r\n" +
                                  $"Interés anual: {interesAnual}%\r\n" +
                                  $"Plazo (meses): {meses}\r\n" +
                                  $"Total a pagar: {totalPagar:C}\r\n" +
                                  $"Fecha: {DateTime.Now}\r\n" +
                                  $"---------------------------\r\n";

                string rutaArchivo = "CotizacionesPrestamos.txt";

                File.AppendAllText(rutaArchivo, contenido);

                MessageBox.Show("Cotización guardada en archivo.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingresa valores numéricos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}");
            }
        }

        private void SimulacionPrestamos_Load(object sender, EventArgs e)
        {

        }
    }
}
