﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BancoApp
{
    public partial class Form1 : Form
    {
        private string conexion = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            CargarTransacciones();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboTipoOperacion.Items.Clear();
            comboTipoOperacion.Items.Add("Deposito");
            comboTipoOperacion.Items.Add("Retiro");
            comboTipoOperacion.Items.Add("Transferencia");
            comboTipoOperacion.SelectedIndex = 0;
        }

        private bool CuentaExiste(int cuentaID)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Cuentas WHERE CuentaID = @cuentaID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }

        private decimal ObtenerSaldo(int cuentaID)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT Saldo FROM Cuentas WHERE CuentaID = @cuentaID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToDecimal(result) : 0m;
            }
        }

        private void ActualizarSaldo(int cuentaID, decimal nuevoSaldo)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();
                string query = "UPDATE Cuentas SET Saldo = @saldo WHERE CuentaID = @cuentaID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@saldo", nuevoSaldo);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                cmd.ExecuteNonQuery();
            }
        }

        private void btnRegistrarTransaccion_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMonto.Text) || !decimal.TryParse(txtMonto.Text, out decimal monto) || monto <= 0)
            {
                MessageBox.Show("Por favor, ingrese un monto válido.");
                return;
            }

            string tipoOperacion = comboTipoOperacion.Text;

            int? cuentaOrigen = null;
            if (!string.IsNullOrWhiteSpace(txtCuentaOrigen.Text) && int.TryParse(txtCuentaOrigen.Text, out int tempOrigen))
            {
                cuentaOrigen = tempOrigen;
            }

            int? cuentaDestino = null;
            if (!string.IsNullOrWhiteSpace(txtCuentaDestino.Text) && int.TryParse(txtCuentaDestino.Text, out int tempDestino))
            {
                cuentaDestino = tempDestino;
            }

            // Validar cuentas
            if (tipoOperacion != "Deposito")
            {
                if (!cuentaOrigen.HasValue)
                {
                    MessageBox.Show("La cuenta origen es obligatoria para Retiro y Transferencia.");
                    return;
                }
                if (!CuentaExiste(cuentaOrigen.Value))
                {
                    MessageBox.Show("La cuenta origen no existe.");
                    return;
                }
            }
            if (tipoOperacion == "Transferencia")
            {
                if (!cuentaDestino.HasValue)
                {
                    MessageBox.Show("La cuenta destino es obligatoria para Transferencia.");
                    return;
                }
                if (!CuentaExiste(cuentaDestino.Value))
                {
                    MessageBox.Show("La cuenta destino no existe.");
                    return;
                }
            }
            if (tipoOperacion == "Deposito" && !cuentaDestino.HasValue)
            {
                MessageBox.Show("La cuenta destino es obligatoria para Depósito.");
                return;
            }

            // Comprobar saldo suficiente para Retiro y Transferencia
            if ((tipoOperacion == "Retiro" || tipoOperacion == "Transferencia") && cuentaOrigen.HasValue)
            {
                decimal saldoActual = ObtenerSaldo(cuentaOrigen.Value);
                if (saldoActual < monto)
                {
                    MessageBox.Show("Saldo insuficiente en la cuenta origen.");
                    return;
                }
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    conn.Open();

                    string insertQuery = @"INSERT INTO Transacciones (IdCuentaOrigen, IdCuentaDestino, TipoOperacion, Monto)
                                           VALUES (@origen, @destino, @tipo, @monto)";

                    SqlCommand cmd = new SqlCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@origen", (object)cuentaOrigen ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@destino", (object)cuentaDestino ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@tipo", tipoOperacion);
                    cmd.Parameters.AddWithValue("@monto", monto);
                    cmd.ExecuteNonQuery();

                    if (tipoOperacion == "Deposito" && cuentaDestino.HasValue)
                    {
                        decimal saldoActual = ObtenerSaldo(cuentaDestino.Value);
                        ActualizarSaldo(cuentaDestino.Value, saldoActual + monto);
                    }
                    else if (tipoOperacion == "Retiro" && cuentaOrigen.HasValue)
                    {
                        decimal saldoActual = ObtenerSaldo(cuentaOrigen.Value);
                        ActualizarSaldo(cuentaOrigen.Value, saldoActual - monto);
                    }
                    else if (tipoOperacion == "Transferencia" && cuentaOrigen.HasValue && cuentaDestino.HasValue)
                    {
                        decimal saldoOrigen = ObtenerSaldo(cuentaOrigen.Value);
                        decimal saldoDestino = ObtenerSaldo(cuentaDestino.Value);
                        ActualizarSaldo(cuentaOrigen.Value, saldoOrigen - monto);
                        ActualizarSaldo(cuentaDestino.Value, saldoDestino + monto);
                    }
                }

                MessageBox.Show("Transacción registrada y saldo actualizado correctamente.");
                CargarTransacciones();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar transacción:\n" + ex.Message);
            }
        }

        // NUEVO: función para obtener saldo inicial justo antes de las transacciones mostradas
        private decimal ObtenerSaldoInicial(int cuentaID, DateTime fechaPrimeraTransaccion)
        {
            decimal saldoActual = ObtenerSaldo(cuentaID);

            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();

                string querySuma = @"
                    SELECT 
                        ISNULL(SUM(CASE 
                            WHEN TipoOperacion = 'Deposito' AND IdCuentaDestino = @cuentaID THEN Monto
                            WHEN TipoOperacion = 'Retiro' AND IdCuentaOrigen = @cuentaID THEN -Monto
                            WHEN TipoOperacion = 'Transferencia' AND IdCuentaOrigen = @cuentaID THEN -Monto
                            WHEN TipoOperacion = 'Transferencia' AND IdCuentaDestino = @cuentaID THEN Monto
                            ELSE 0
                        END), 0)
                    FROM Transacciones
                    WHERE (IdCuentaOrigen = @cuentaID OR IdCuentaDestino = @cuentaID)
                      AND Fecha >= @fecha";

                SqlCommand cmd = new SqlCommand(querySuma, conn);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                cmd.Parameters.AddWithValue("@fecha", fechaPrimeraTransaccion);

                decimal sumaPosterior = (decimal)cmd.ExecuteScalar();

                return saldoActual - sumaPosterior;
            }
        }

        private void CargarTransacciones()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    conn.Open();

                    string query = @"
                        SELECT 
                            IdTransaccion,
                            IdCuentaOrigen,
                            IdCuentaDestino,
                            TipoOperacion,
                            Monto,
                            Fecha
                        FROM Transacciones
                        ORDER BY Fecha ASC, IdTransaccion ASC";

                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    DataTable dtConSaldo = dt.Clone();
                    dtConSaldo.Columns.Add("SaldoAntes", typeof(decimal));
                    dtConSaldo.Columns.Add("SaldoDespues", typeof(decimal));

                    // Obtener fecha mínima de todas las transacciones (la más antigua)
                    DateTime fechaMinima = DateTime.MaxValue;
                    foreach (DataRow row in dt.Rows)
                    {
                        DateTime fecha = Convert.ToDateTime(row["Fecha"]);
                        if (fecha < fechaMinima)
                            fechaMinima = fecha;
                    }

                    // Diccionario para guardar saldo inicial de cada cuenta
                    Dictionary<int, decimal> saldos = new Dictionary<int, decimal>();

                    foreach (DataRow row in dt.Rows)
                    {
                        int? origen = row["IdCuentaOrigen"] != DBNull.Value ? Convert.ToInt32(row["IdCuentaOrigen"]) : (int?)null;
                        int? destino = row["IdCuentaDestino"] != DBNull.Value ? Convert.ToInt32(row["IdCuentaDestino"]) : (int?)null;

                        if (origen.HasValue && !saldos.ContainsKey(origen.Value))
                            saldos[origen.Value] = ObtenerSaldoInicial(origen.Value, fechaMinima);

                        if (destino.HasValue && !saldos.ContainsKey(destino.Value))
                            saldos[destino.Value] = ObtenerSaldoInicial(destino.Value, fechaMinima);
                    }

                    // Calcular saldos antes y después de cada transacción
                    foreach (DataRow row in dt.Rows)
                    {
                        int? origen = row["IdCuentaOrigen"] != DBNull.Value ? Convert.ToInt32(row["IdCuentaOrigen"]) : (int?)null;
                        int? destino = row["IdCuentaDestino"] != DBNull.Value ? Convert.ToInt32(row["IdCuentaDestino"]) : (int?)null;
                        string tipo = row["TipoOperacion"].ToString();
                        decimal monto = Convert.ToDecimal(row["Monto"]);

                        decimal saldoAntes = 0;
                        decimal saldoDespues = 0;

                        if (tipo == "Deposito" && destino.HasValue)
                        {
                            saldoAntes = saldos[destino.Value];
                            saldos[destino.Value] += monto;
                            saldoDespues = saldos[destino.Value];
                        }
                        else if (tipo == "Retiro" && origen.HasValue)
                        {
                            saldoAntes = saldos[origen.Value];
                            saldos[origen.Value] -= monto;
                            saldoDespues = saldos[origen.Value];
                        }
                        else if (tipo == "Transferencia" && origen.HasValue && destino.HasValue)
                        {
                            saldoAntes = saldos[origen.Value];
                            saldos[origen.Value] -= monto;
                            saldos[destino.Value] += monto;
                            saldoDespues = saldos[origen.Value];
                        }

                        DataRow nuevaFila = dtConSaldo.NewRow();
                        nuevaFila.ItemArray = row.ItemArray.Clone() as object[];
                        nuevaFila["SaldoAntes"] = saldoAntes;
                        nuevaFila["SaldoDespues"] = saldoDespues;
                        dtConSaldo.Rows.Add(nuevaFila);
                    }

                    DataView vista = dtConSaldo.DefaultView;
                    vista.Sort = "Fecha DESC, IdTransaccion DESC";
                    dgvTransacciones.DataSource = vista;

                    dgvTransacciones.Columns["IdTransaccion"].HeaderText = "ID Transacción";
                    dgvTransacciones.Columns["IdCuentaOrigen"].HeaderText = "Cuenta Origen";
                    dgvTransacciones.Columns["IdCuentaDestino"].HeaderText = "Cuenta Destino";
                    dgvTransacciones.Columns["TipoOperacion"].HeaderText = "Operación";
                    dgvTransacciones.Columns["Monto"].HeaderText = "Monto";
                    dgvTransacciones.Columns["Fecha"].HeaderText = "Fecha";
                    dgvTransacciones.Columns["SaldoAntes"].HeaderText = "Saldo Antes";
                    dgvTransacciones.Columns["SaldoDespues"].HeaderText = "Saldo Después";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar transacciones:\n" + ex.Message);
            }
        }
    }
}

