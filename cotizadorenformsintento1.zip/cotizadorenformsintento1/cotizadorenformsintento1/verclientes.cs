﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace verclientes
{
    public partial class VerClientes : Form
    {
        public VerClientes()
        {
            InitializeComponent();
            CargarClientes();
        }

        private void CargarClientes()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT ClienteID, Nombre, Cedula, Correo, Telefono FROM Clientes";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvClientes.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar clientes: {ex.Message}");
            }
        }


        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            CargarClientes();
        }
    }
}
