﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TuNamespace
{
    public partial class GestionClientes : Form
    {
        private DataTable dtClientes;
        private SqlDataAdapter da;
        private SqlConnection conn;
        private SqlCommandBuilder cmdBuilder;

        public GestionClientes()
        {
            InitializeComponent();
        }

        private void GestionClientes_Load(object sender, EventArgs e)
        {
            CargarClientes();
        }

        private void CargarClientes()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                conn = new SqlConnection(connectionString);
                da = new SqlDataAdapter("SELECT ClienteID, Nombre, Cedula, Correo, Telefono FROM Clientes", conn);
                cmdBuilder = new SqlCommandBuilder(da);
                dtClientes = new DataTable();
                da.Fill(dtClientes);

                dgvClientes.DataSource = dtClientes;
                dgvClientes.Columns["ClienteID"].ReadOnly = true; // ID no editable
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar clientes: " + ex.Message);
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dtClientes);
                MessageBox.Show("Datos actualizados correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar datos: " + ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow != null)
            {
                DialogResult resultado = MessageBox.Show("¿Está seguro de eliminar el cliente seleccionado?", "Confirmar eliminación", MessageBoxButtons.YesNo);
                if (resultado == DialogResult.Yes)
                {
                    try
                    {
                        dgvClientes.Rows.RemoveAt(dgvClientes.CurrentRow.Index);
                        da.Update(dtClientes);
                        MessageBox.Show("Cliente eliminado correctamente.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al eliminar cliente: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un cliente para eliminar.");
            }
        }
    }
}
