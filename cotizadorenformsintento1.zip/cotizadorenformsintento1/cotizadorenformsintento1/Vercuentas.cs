﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace cotizadorenformsintento1
{
    public partial class VerCuentas : Form
    {
        public VerCuentas()
        {
            InitializeComponent();
            CargarCuentas();
        }

        private void CargarCuentas()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                SELECT c.CuentaID, cl.Nombre, cl.Cedula, c.TipoCuenta, c.Saldo
                FROM Cuentas c
                INNER JOIN Clientes cl ON c.ClienteID = cl.ClienteID";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dgvCuentas.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar cuentas: {ex.Message}");
            }
        }


        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            CargarCuentas();
        }
    }
}
