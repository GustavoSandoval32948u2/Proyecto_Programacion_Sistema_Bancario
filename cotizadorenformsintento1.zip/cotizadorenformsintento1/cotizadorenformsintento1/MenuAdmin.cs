﻿using System;
using System.Windows.Forms;
using AbrirCuen;
using BancoApp;
using cotizadorenformsintento1;
using Gestion;
using TuNamespace;
using verclientes;

namespace menuadmin
{
    public partial class MenuAdministrador : Form
    {
        public MenuAdministrador()
        {
            InitializeComponent();
        }

        private void btnVerClientes_Click(object sender, EventArgs e)
        {
            VerClientes verClientes = new VerClientes();
            verClientes.Show();
        }

        private void btnVerCuentas_Click(object sender, EventArgs e)
        {
            VerCuentas verCuentasForm = new VerCuentas();
            verCuentasForm.ShowDialog();
        }

        private void btnGestionCuentas_Click(object sender, EventArgs e)
        {
            GestionCuentas abrirCuentaForm = new GestionCuentas(); 
            abrirCuentaForm.ShowDialog();
        }
        private void btnVerPrestamos_Click(object sender, EventArgs e)
        {
            VerPrestamos form = new VerPrestamos();
            form.ShowDialog();
        }

        private void btnAbrirCuentas_Click(object sender, EventArgs e)
        {
            AbrirCuentas form = new AbrirCuentas();
            form.ShowDialog();
        }

        private void btnGestionClientes_Click(object sender, EventArgs e)
        {
            GestionClientes gestionClientesForm = new GestionClientes();
            gestionClientesForm.ShowDialog(); 
        }

        private void btnTransacciones_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
        }


    }
}
