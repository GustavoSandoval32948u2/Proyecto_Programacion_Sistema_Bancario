﻿namespace BancoApp
{
    partial class Form1
    {

        private System.ComponentModel.IContainer components = null;

        /// <param name="disposing"
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboTipoOperacion = new System.Windows.Forms.ComboBox();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.txtCuentaOrigen = new System.Windows.Forms.TextBox();
            this.txtCuentaDestino = new System.Windows.Forms.TextBox();
            this.btnRegistrarTransaccion = new System.Windows.Forms.Button();
            this.dgvTransacciones = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacciones)).BeginInit();
            this.SuspendLayout();
            // 
            // comboTipoOperacion
            // 
            this.comboTipoOperacion.BackColor = System.Drawing.SystemColors.Info;
            this.comboTipoOperacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboTipoOperacion.Font = new System.Drawing.Font("Segoe UI Black", 12F);
            this.comboTipoOperacion.FormattingEnabled = true;
            this.comboTipoOperacion.Location = new System.Drawing.Point(110, 63);
            this.comboTipoOperacion.Name = "comboTipoOperacion";
            this.comboTipoOperacion.Size = new System.Drawing.Size(139, 40);
            this.comboTipoOperacion.TabIndex = 0;
            // 
            // txtMonto
            // 
            this.txtMonto.BackColor = System.Drawing.SystemColors.Info;
            this.txtMonto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMonto.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonto.Location = new System.Drawing.Point(559, 65);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(107, 32);
            this.txtMonto.TabIndex = 1;
            this.txtMonto.Text = "Monto";
            // 
            // txtCuentaOrigen
            // 
            this.txtCuentaOrigen.BackColor = System.Drawing.SystemColors.Info;
            this.txtCuentaOrigen.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaOrigen.Location = new System.Drawing.Point(722, 65);
            this.txtCuentaOrigen.Name = "txtCuentaOrigen";
            this.txtCuentaOrigen.Size = new System.Drawing.Size(172, 39);
            this.txtCuentaOrigen.TabIndex = 2;
            this.txtCuentaOrigen.Text = "Cuenta origen";
            // 
            // txtCuentaDestino
            // 
            this.txtCuentaDestino.BackColor = System.Drawing.SystemColors.Info;
            this.txtCuentaDestino.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaDestino.Location = new System.Drawing.Point(301, 65);
            this.txtCuentaDestino.Name = "txtCuentaDestino";
            this.txtCuentaDestino.Size = new System.Drawing.Size(183, 39);
            this.txtCuentaDestino.TabIndex = 3;
            this.txtCuentaDestino.Text = "Cuenta destino";
            // 
            // btnRegistrarTransaccion
            // 
            this.btnRegistrarTransaccion.BackColor = System.Drawing.SystemColors.Info;
            this.btnRegistrarTransaccion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrarTransaccion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarTransaccion.Location = new System.Drawing.Point(493, 145);
            this.btnRegistrarTransaccion.Name = "btnRegistrarTransaccion";
            this.btnRegistrarTransaccion.Size = new System.Drawing.Size(166, 77);
            this.btnRegistrarTransaccion.TabIndex = 4;
            this.btnRegistrarTransaccion.Text = "Registrar Transacción";
            this.btnRegistrarTransaccion.UseVisualStyleBackColor = false;
            this.btnRegistrarTransaccion.Click += new System.EventHandler(this.btnRegistrarTransaccion_Click);
            // 
            // dgvTransacciones
            // 
            this.dgvTransacciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTransacciones.Location = new System.Drawing.Point(209, 252);
            this.dgvTransacciones.Name = "dgvTransacciones";
            this.dgvTransacciones.RowHeadersWidth = 62;
            this.dgvTransacciones.RowTemplate.Height = 28;
            this.dgvTransacciones.Size = new System.Drawing.Size(778, 247);
            this.dgvTransacciones.TabIndex = 5;
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1191, 607);
            this.Controls.Add(this.dgvTransacciones);
            this.Controls.Add(this.btnRegistrarTransaccion);
            this.Controls.Add(this.txtCuentaDestino);
            this.Controls.Add(this.txtCuentaOrigen);
            this.Controls.Add(this.txtMonto);
            this.Controls.Add(this.comboTipoOperacion);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboTipoOperacion;
        private System.Windows.Forms.TextBox txtMonto;
        private System.Windows.Forms.TextBox txtCuentaOrigen;
        private System.Windows.Forms.TextBox txtCuentaDestino;
        private System.Windows.Forms.Button btnRegistrarTransaccion;
        private System.Windows.Forms.DataGridView dgvTransacciones;
    }
}
