﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BancoApp
{
    public partial class Form1 : Form
    {
        private string conexion = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            CargarTransacciones();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboTipoOperacion.Items.Clear();
            comboTipoOperacion.Items.Add("Deposito");
            comboTipoOperacion.Items.Add("Retiro");
            comboTipoOperacion.Items.Add("Transferencia");
            comboTipoOperacion.SelectedIndex = 0;
        }

        private bool CuentaExiste(int cuentaID)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Cuentas WHERE CuentaID = @cuentaID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }

        private decimal ObtenerSaldo(int cuentaID)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT Saldo FROM Cuentas WHERE CuentaID = @cuentaID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToDecimal(result) : 0m;
            }
        }

        private void ActualizarSaldo(int cuentaID, decimal nuevoSaldo)
        {
            using (SqlConnection conn = new SqlConnection(conexion))
            {
                conn.Open();
                string query = "UPDATE Cuentas SET Saldo = @saldo WHERE CuentaID = @cuentaID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@saldo", nuevoSaldo);
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                cmd.ExecuteNonQuery();
            }
        }

        private void btnRegistrarTransaccion_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMonto.Text) || !decimal.TryParse(txtMonto.Text, out decimal monto) || monto <= 0)
            {
                MessageBox.Show("Por favor, ingrese un monto válido.");
                return;
            }

            string tipoOperacion = comboTipoOperacion.Text;

            int? cuentaOrigen = null;
            if (!string.IsNullOrWhiteSpace(txtCuentaOrigen.Text) && int.TryParse(txtCuentaOrigen.Text, out int tempOrigen))
            {
                cuentaOrigen = tempOrigen;
            }

            int? cuentaDestino = null;
            if (!string.IsNullOrWhiteSpace(txtCuentaDestino.Text) && int.TryParse(txtCuentaDestino.Text, out int tempDestino))
            {
                cuentaDestino = tempDestino;
            }

            // Validar cuentas
            if (tipoOperacion != "Deposito")
            {
                if (!cuentaOrigen.HasValue)
                {
                    MessageBox.Show("La cuenta origen es obligatoria para Retiro y Transferencia.");
                    return;
                }
                if (!CuentaExiste(cuentaOrigen.Value))
                {
                    MessageBox.Show("La cuenta origen no existe.");
                    return;
                }
            }
            if (tipoOperacion == "Transferencia")
            {
                if (!cuentaDestino.HasValue)
                {
                    MessageBox.Show("La cuenta destino es obligatoria para Transferencia.");
                    return;
                }
                if (!CuentaExiste(cuentaDestino.Value))
                {
                    MessageBox.Show("La cuenta destino no existe.");
                    return;
                }
            }
            if (tipoOperacion == "Deposito" && !cuentaDestino.HasValue)
            {
                MessageBox.Show("La cuenta destino es obligatoria para Depósito.");
                return;
            }

            // Comprobar saldo suficiente para Retiro y Transferencia
            if ((tipoOperacion == "Retiro" || tipoOperacion == "Transferencia") && cuentaOrigen.HasValue)
            {
                decimal saldoActual = ObtenerSaldo(cuentaOrigen.Value);
                if (saldoActual < monto)
                {
                    MessageBox.Show("Saldo insuficiente en la cuenta origen.");
                    return;
                }
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    conn.Open();

                    // Insertar transacción
                    string insertQuery = @"INSERT INTO Transacciones (IdCuentaOrigen, IdCuentaDestino, TipoOperacion, Monto)
                                           VALUES (@origen, @destino, @tipo, @monto)";

                    SqlCommand cmd = new SqlCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@origen", (object)cuentaOrigen ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@destino", (object)cuentaDestino ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@tipo", tipoOperacion);
                    cmd.Parameters.AddWithValue("@monto", monto);
                    cmd.ExecuteNonQuery();

                    // Actualizar saldo según tipo de operación
                    if (tipoOperacion == "Deposito" && cuentaDestino.HasValue)
                    {
                        decimal saldoActual = ObtenerSaldo(cuentaDestino.Value);
                        ActualizarSaldo(cuentaDestino.Value, saldoActual + monto);
                    }
                    else if (tipoOperacion == "Retiro" && cuentaOrigen.HasValue)
                    {
                        decimal saldoActual = ObtenerSaldo(cuentaOrigen.Value);
                        ActualizarSaldo(cuentaOrigen.Value, saldoActual - monto);
                    }
                    else if (tipoOperacion == "Transferencia" && cuentaOrigen.HasValue && cuentaDestino.HasValue)
                    {
                        decimal saldoOrigen = ObtenerSaldo(cuentaOrigen.Value);
                        decimal saldoDestino = ObtenerSaldo(cuentaDestino.Value);
                        ActualizarSaldo(cuentaOrigen.Value, saldoOrigen - monto);
                        ActualizarSaldo(cuentaDestino.Value, saldoDestino + monto);
                    }
                }

                MessageBox.Show("Transacción registrada y saldo actualizado correctamente.");
                CargarTransacciones();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar transacción:\n" + ex.Message);
            }
        }

        private void CargarTransacciones()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    conn.Open();

                    string query = @"
                SELECT 
                    IdTransaccion,
                    IdCuentaOrigen,
                    IdCuentaDestino,
                    TipoOperacion,
                    Monto,
                    Fecha
                FROM Transacciones
                ORDER BY Fecha DESC"; // Orden cronológico para simular correctamente

                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Clonar estructura y agregar nueva columna
                    DataTable dtConSaldo = dt.Clone();
                    dtConSaldo.Columns.Add("SaldoDespues", typeof(decimal));

                    // Diccionario para llevar el saldo acumulado de cada cuenta
                    Dictionary<int, decimal> saldos = new Dictionary<int, decimal>();

                    foreach (DataRow row in dt.Rows)
                    {
                        int? origen = row["IdCuentaOrigen"] != DBNull.Value ? Convert.ToInt32(row["IdCuentaOrigen"]) : (int?)null;
                        int? destino = row["IdCuentaDestino"] != DBNull.Value ? Convert.ToInt32(row["IdCuentaDestino"]) : (int?)null;
                        string tipo = row["TipoOperacion"].ToString();
                        decimal monto = Convert.ToDecimal(row["Monto"]);

                        // Inicializar saldos si no están
                        if (origen.HasValue && !saldos.ContainsKey(origen.Value))
                            saldos[origen.Value] = ObtenerSaldoInicial(conn, origen.Value, row["Fecha"]);

                        if (destino.HasValue && !saldos.ContainsKey(destino.Value))
                            saldos[destino.Value] = ObtenerSaldoInicial(conn, destino.Value, row["Fecha"]);

                        decimal saldoDespues = 0;

                        // Simular cambios
                        if (tipo == "Deposito" && destino.HasValue)
                        {
                            saldos[destino.Value] += monto;
                            saldoDespues = saldos[destino.Value];
                        }
                        else if (tipo == "Retiro" && origen.HasValue)
                        {
                            saldos[origen.Value] -= monto;
                            saldoDespues = saldos[origen.Value];
                        }
                        else if (tipo == "Transferencia" && origen.HasValue && destino.HasValue)
                        {
                            saldos[origen.Value] -= monto;
                            saldos[destino.Value] += monto;
                            saldoDespues = saldos[origen.Value]; // Solo mostramos saldo después en la cuenta origen
                        }

                        // Crear nueva fila con saldo
                        DataRow nuevaFila = dtConSaldo.NewRow();
                        nuevaFila.ItemArray = row.ItemArray.Clone() as object[];
                        nuevaFila["SaldoDespues"] = saldoDespues;

                        dtConSaldo.Rows.Add(nuevaFila);
                    }

                    dgvTransacciones.DataSource = dtConSaldo;

                    dgvTransacciones.Columns["IdTransaccion"].HeaderText = "ID Transacción";
                    dgvTransacciones.Columns["IdCuentaOrigen"].HeaderText = "Cuenta Origen";
                    dgvTransacciones.Columns["IdCuentaDestino"].HeaderText = "Cuenta Destino";
                    dgvTransacciones.Columns["TipoOperacion"].HeaderText = "Operación";
                    dgvTransacciones.Columns["Monto"].HeaderText = "Monto";
                    dgvTransacciones.Columns["Fecha"].HeaderText = "Fecha";
                    dgvTransacciones.Columns["SaldoDespues"].HeaderText = "Saldo Después";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar transacciones:\n" + ex.Message);
            }
        }

        // Método auxiliar para obtener el saldo inicial antes de la primera transacción
        private decimal ObtenerSaldoInicial(SqlConnection conn, int cuentaID, object fechaActual)
        {
            string query = @"
        SELECT SUM(
            CASE 
                WHEN TipoOperacion = 'Deposito' AND IdCuentaDestino = @cuentaID THEN Monto
                WHEN TipoOperacion = 'Retiro' AND IdCuentaOrigen = @cuentaID THEN -Monto
                WHEN TipoOperacion = 'Transferencia' AND IdCuentaDestino = @cuentaID THEN Monto
                WHEN TipoOperacion = 'Transferencia' AND IdCuentaOrigen = @cuentaID THEN -Monto
                ELSE 0
            END
        ) 
        FROM Transacciones
        WHERE Fecha < @fecha";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@cuentaID", cuentaID);
                cmd.Parameters.AddWithValue("@fecha", fechaActual);
                object result = cmd.ExecuteScalar();
                return result != DBNull.Value ? Convert.ToDecimal(result) : 0m;
            }
        }

    }
}

