﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gestion
{
    public partial class GestionCuentas : Form
    {
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

        public GestionCuentas()
        {
            InitializeComponent();
        }

        private void frmGestionarCuentas_Load(object sender, EventArgs e)
        {
            CargarCuentas();
        }


        private void CargarCuentas()
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    string query = @"
                SELECT 
                    Cuentas.CuentaID,
                    Clientes.Nombre AS NombreCliente,
                    Cuentas.TipoCuenta,
                    Cuentas.Saldo
                FROM Cuentas
                INNER JOIN Clientes ON Cuentas.ClienteID = Clientes.ClienteID";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conexion))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridViewCuentas.DataSource = dt;

                        dataGridViewCuentas.ReadOnly = false;
                        foreach (DataGridViewColumn col in dataGridViewCuentas.Columns)
                        {
                            if (col.Name == "NombreCliente")
                                col.ReadOnly = false;
                            else
                                col.ReadOnly = true;
                        }

                    }
                }

                // Cambiar encabezados si lo deseas
                dataGridViewCuentas.Columns["CuentaID"].HeaderText = "ID Cuenta";
                dataGridViewCuentas.Columns["NombreCliente"].HeaderText = "Cliente";
                dataGridViewCuentas.Columns["TipoCuenta"].HeaderText = "Tipo de Cuenta";
                dataGridViewCuentas.Columns["Saldo"].HeaderText = "Saldo Actual";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las cuentas:\n" + ex.Message);
            }
        }



        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (dataGridViewCuentas.CurrentRow != null)
            {
                try
                {
                    int cuentaId = Convert.ToInt32(dataGridViewCuentas.CurrentRow.Cells["CuentaID"].Value);
                    string nuevoNombre = dataGridViewCuentas.CurrentRow.Cells["NombreCliente"].Value.ToString();

                    using (SqlConnection conexion = new SqlConnection(connectionString))
                    {
                        conexion.Open();

                        // Obtener el ClienteID a partir del CuentaID
                        string obtenerClienteIdQuery = "SELECT ClienteID FROM Cuentas WHERE CuentaID = @cuentaId";
                        int clienteId;

                        using (SqlCommand cmdCliente = new SqlCommand(obtenerClienteIdQuery, conexion))
                        {
                            cmdCliente.Parameters.AddWithValue("@cuentaId", cuentaId);
                            object result = cmdCliente.ExecuteScalar();
                            if (result == null)
                            {
                                MessageBox.Show("No se encontró el cliente asociado.");
                                return;
                            }
                            clienteId = Convert.ToInt32(result);
                        }

                        // Actualizar solo el nombre del cliente
                        string actualizarNombreQuery = "UPDATE Clientes SET Nombre = @nuevoNombre WHERE ClienteID = @clienteId";
                        using (SqlCommand cmdActualizar = new SqlCommand(actualizarNombreQuery, conexion))
                        {
                            cmdActualizar.Parameters.AddWithValue("@nuevoNombre", nuevoNombre);
                            cmdActualizar.Parameters.AddWithValue("@clienteId", clienteId);
                            cmdActualizar.ExecuteNonQuery();
                        }

                        MessageBox.Show("Nombre del cliente actualizado correctamente.");
                        CargarCuentas();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar nombre del cliente: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Selecciona una cuenta para actualizar.");
            }
        }


        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridViewCuentas.CurrentRow != null)
            {
                try
                {
                    int cuentaId = Convert.ToInt32(dataGridViewCuentas.CurrentRow.Cells["CuentaID"].Value);
                    DialogResult result = MessageBox.Show("¿Seguro que quieres eliminar esta cuenta?", "Confirmar eliminación", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection conexion = new SqlConnection(connectionString))
                        {
                            conexion.Open();
                            string query = "DELETE FROM Cuentas WHERE CuentaID=@cuentaId";
                            using (SqlCommand cmd = new SqlCommand(query, conexion))
                            {
                                cmd.Parameters.AddWithValue("@cuentaId", cuentaId);
                                int filas = cmd.ExecuteNonQuery();
                                if (filas > 0)
                                {
                                    MessageBox.Show("Cuenta eliminada correctamente.");
                                    CargarCuentas();
                                }
                                else
                                {
                                    MessageBox.Show("No se pudo eliminar la cuenta.");
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar cuenta: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Selecciona una cuenta para eliminar.");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
