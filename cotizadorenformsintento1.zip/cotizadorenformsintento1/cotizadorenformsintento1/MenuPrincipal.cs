﻿using System;
using System.Windows.Forms;
using AbrirCuen;
using Simulacion;
using BancoApp;
using cotizadorenformsintento1;
using Gestion;

namespace Menu
{
    public partial class MenuPrincipal : Form
    {
        public MenuPrincipal()
        {
            InitializeComponent();
        }

        private void btnAbrirCuentas_Click(object sender, EventArgs e)
        {
            AbrirCuentas form = new AbrirCuentas();
            form.ShowDialog();
        }

        private void btnSimularPrestamo_Click(object sender, EventArgs e)
        {
            SimulacionPrestamos form = new SimulacionPrestamos();
            form.ShowDialog();
        }

        private void btnTransacciones_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(); 
            form.ShowDialog();
        }

        private void btnGestionCuentas_Click(object sender, EventArgs e)
        {
            GestionCuentas form = new GestionCuentas(); 
            form.ShowDialog();
        }

        private void btnPrestamos_Click(object sender, EventArgs e)
        {
            prestamos form = new prestamos(); 
            form.ShowDialog();
        }
    }
}
