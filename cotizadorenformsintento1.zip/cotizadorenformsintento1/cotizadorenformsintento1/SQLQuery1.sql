﻿CREATE TABLE Prestamos (
    IdPrestamo INT PRIMARY KEY IDENTITY(1,1),
    NombreCliente NVARCHAR(100),
    MontoSolicitado DECIMAL(18,2),
    PorcentajeInteres DECIMAL(5,2),
    NumeroMeses INT,
    FechaInicio DATE,
    CuotaMensual DECIMAL(18,2)
);
