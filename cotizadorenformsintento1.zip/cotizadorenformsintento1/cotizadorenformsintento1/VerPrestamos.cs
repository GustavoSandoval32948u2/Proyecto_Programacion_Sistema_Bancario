﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace cotizadorenformsintento1
{
    public partial class VerPrestamos : Form
    {
        public VerPrestamos()
        {
            InitializeComponent();
            CargarPrestamos();
        }

        private void CargarPrestamos()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM Prestamos";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable prestamosTable = new DataTable();
                    adapter.Fill(prestamosTable);
                    dgvPrestamos.DataSource = prestamosTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar préstamos: " + ex.Message);
            }
        }
    }
}
