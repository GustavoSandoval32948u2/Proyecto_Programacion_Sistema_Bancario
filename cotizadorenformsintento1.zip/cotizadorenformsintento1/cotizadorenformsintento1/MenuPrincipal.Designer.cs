﻿namespace Menu
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnTransacciones = new System.Windows.Forms.Button();
            this.btnSimularPrestamo = new System.Windows.Forms.Button();
            this.btnAbrirCuentas = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(189, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(407, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sistema Bancario - Menú Principal";
            // 
            // btnTransacciones
            // 
            this.btnTransacciones.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransacciones.Location = new System.Drawing.Point(584, 214);
            this.btnTransacciones.Name = "btnTransacciones";
            this.btnTransacciones.Size = new System.Drawing.Size(167, 93);
            this.btnTransacciones.TabIndex = 1;
            this.btnTransacciones.Text = "Transacciones";
            this.btnTransacciones.UseVisualStyleBackColor = true;
            this.btnTransacciones.Click += new System.EventHandler(this.btnTransacciones_Click);
            // 
            // btnSimularPrestamo
            // 
            this.btnSimularPrestamo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimularPrestamo.Location = new System.Drawing.Point(417, 214);
            this.btnSimularPrestamo.Name = "btnSimularPrestamo";
            this.btnSimularPrestamo.Size = new System.Drawing.Size(143, 93);
            this.btnSimularPrestamo.TabIndex = 2;
            this.btnSimularPrestamo.Text = "Simular Prestamo";
            this.btnSimularPrestamo.UseVisualStyleBackColor = true;
            this.btnSimularPrestamo.Click += new System.EventHandler(this.btnSimularPrestamo_Click);
            // 
            // btnAbrirCuentas
            // 
            this.btnAbrirCuentas.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbrirCuentas.Location = new System.Drawing.Point(265, 214);
            this.btnAbrirCuentas.Name = "btnAbrirCuentas";
            this.btnAbrirCuentas.Size = new System.Drawing.Size(134, 93);
            this.btnAbrirCuentas.TabIndex = 3;
            this.btnAbrirCuentas.Text = "Abrir Cuentas";
            this.btnAbrirCuentas.UseVisualStyleBackColor = true;
            this.btnAbrirCuentas.Click += new System.EventHandler(this.btnAbrirCuentas_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(56, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 100);
            this.button1.TabIndex = 5;
            this.button1.Text = "Prestamos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnPrestamos_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(195, 351);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(134, 93);
            this.button2.TabIndex = 6;
            this.button2.Text = "Ver mi Cuenta";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnVerCuentas_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(383, 351);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(134, 93);
            this.button3.TabIndex = 7;
            this.button3.Text = "Ver mis Prestamos";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnVerPrestamos_Click);
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(800, 490);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAbrirCuentas);
            this.Controls.Add(this.btnSimularPrestamo);
            this.Controls.Add(this.btnTransacciones);
            this.Controls.Add(this.label1);
            this.Name = "MenuPrincipal";
            this.Text = "MenuPrincipal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTransacciones;
        private System.Windows.Forms.Button btnSimularPrestamo;
        private System.Windows.Forms.Button btnAbrirCuentas;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}