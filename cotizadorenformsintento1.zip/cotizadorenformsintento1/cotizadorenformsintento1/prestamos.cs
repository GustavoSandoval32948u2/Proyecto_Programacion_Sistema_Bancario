﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace cotizadorenformsintento1
{
    public partial class prestamos : Form
    {
        public prestamos()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nombreCliente = txtNombreCliente.Text;
                decimal montoSolicitado = decimal.Parse(txtMontoSolicitado.Text);
                decimal porcentajeInteres = decimal.Parse(txtPorcentajeInteres.Text) / 100;
                int numeroMeses = int.Parse(txtNumeroMeses.Text);
                DateTime fechaInicio = DateTime.Parse(txtFechaInicio.Text);

                decimal tasaMensual = porcentajeInteres / 12;
                decimal cuotaMensual = montoSolicitado * (tasaMensual * (decimal)Math.Pow(1 + (double)tasaMensual, numeroMeses)) /
                                       ((decimal)Math.Pow(1 + (double)tasaMensual, numeroMeses) - 1);

                pagos.Items.Clear();
                for (int i = 1; i <= numeroMeses; i++)
                {
                    DateTime fechaPago = fechaInicio.AddMonths(i);
                    pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                }

                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO Prestamos 
                                    (NombreCliente, MontoSolicitado, PorcentajeInteres, NumeroMeses, FechaInicio, CuotaMensual)
                                    VALUES (@NombreCliente, @MontoSolicitado, @PorcentajeInteres, @NumeroMeses, @FechaInicio, @CuotaMensual)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@NombreCliente", nombreCliente);
                        cmd.Parameters.AddWithValue("@MontoSolicitado", montoSolicitado);
                        cmd.Parameters.AddWithValue("@PorcentajeInteres", porcentajeInteres * 100); 
                        cmd.Parameters.AddWithValue("@NumeroMeses", numeroMeses);
                        cmd.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                        cmd.Parameters.AddWithValue("@CuotaMensual", cuotaMensual);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Préstamo calculado y guardado exitosamente.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese datos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}");
            }
        }
    }
}
