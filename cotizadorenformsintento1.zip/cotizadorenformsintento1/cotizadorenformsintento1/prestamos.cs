﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace cotizadorenformsintento1
{
    public partial class prestamos : Form
    {
        public prestamos()
        {
            InitializeComponent();
            cmbTipoInteres.Items.Add("Simple");
            cmbTipoInteres.Items.Add("Compuesto");
            cmbTipoInteres.Items.Add("Amortizable (cuota fija)");
            cmbTipoInteres.SelectedIndex = 0; // Selecciona por defecto "Simple"

            CargarClientes();

        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void CargarClientes()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT Nombre FROM Clientes";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbNombreCliente.Items.Add(reader["Nombre"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los nombres de los clientes: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nombreCliente = cmbNombreCliente.Text;
                decimal montoSolicitado = decimal.Parse(txtMontoSolicitado.Text);
                decimal porcentajeInteres = decimal.Parse(txtPorcentajeInteres.Text) / 100;
                int numeroMeses = int.Parse(txtNumeroMeses.Text);
                DateTime fechaInicio = DateTime.Parse(txtFechaInicio.Text);

                string tipoInteres = cmbTipoInteres.SelectedItem.ToString();
                pagos.Items.Clear();

                decimal cuotaMensual = 0;

                if (tipoInteres == "Simple")
                {
                    // Interés simple
                    decimal montoTotal = montoSolicitado * (1 + porcentajeInteres * numeroMeses / 12);
                    cuotaMensual = montoTotal / numeroMeses;

                    for (int i = 1; i <= numeroMeses; i++)
                    {
                        DateTime fechaPago = fechaInicio.AddMonths(i);
                        pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                    }
                }
                else if (tipoInteres == "Compuesto")
                {
                    // Interés compuesto
                    decimal montoTotal = montoSolicitado * (decimal)Math.Pow((double)(1 + porcentajeInteres / 12), numeroMeses);
                    cuotaMensual = montoTotal / numeroMeses;

                    for (int i = 1; i <= numeroMeses; i++)
                    {
                        DateTime fechaPago = fechaInicio.AddMonths(i);
                        pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                    }
                }
                else if (tipoInteres == "Amortizable (cuota fija)")
                {
                    // Amortización con cuota fija (ya lo tenías)
                    decimal tasaMensual = porcentajeInteres / 12;
                    cuotaMensual = montoSolicitado * (tasaMensual * (decimal)Math.Pow(1 + (double)tasaMensual, numeroMeses)) /
                                   ((decimal)Math.Pow(1 + (double)tasaMensual, numeroMeses) - 1);

                    for (int i = 1; i <= numeroMeses; i++)
                    {
                        DateTime fechaPago = fechaInicio.AddMonths(i);
                        pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                    }
                }

                // Guardar en la base de datos
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO Prestamos 
                            (NombreCliente, MontoSolicitado, PorcentajeInteres, NumeroMeses, FechaInicio, CuotaMensual)
                            VALUES (@NombreCliente, @MontoSolicitado, @PorcentajeInteres, @NumeroMeses, @FechaInicio, @CuotaMensual)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@NombreCliente", nombreCliente);
                        cmd.Parameters.AddWithValue("@MontoSolicitado", montoSolicitado);
                        cmd.Parameters.AddWithValue("@PorcentajeInteres", porcentajeInteres * 100);
                        cmd.Parameters.AddWithValue("@NumeroMeses", numeroMeses);
                        cmd.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                        cmd.Parameters.AddWithValue("@CuotaMensual", cuotaMensual);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Préstamo calculado y guardado exitosamente.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese datos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}");
            }
        }

    }
}
