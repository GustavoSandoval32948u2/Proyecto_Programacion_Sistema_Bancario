﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Menu;
using menuadmin;

namespace Logeo_Proyecto
{
    public partial class Login : Form
    {

        SqlConnection conexion = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True");

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsuario.Text) || string.IsNullOrWhiteSpace(txtContra.Text))
            {
                MessageBox.Show("Por favor complete todos los campos.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True"))
                {
                    con.Open();

                    string consultaAdmin = "SELECT COUNT(*) FROM administradores WHERE usuario = @usuario AND contraseña = @contraseña";
                    using (SqlCommand cmdAdmin = new SqlCommand(consultaAdmin, con))
                    {
                        cmdAdmin.Parameters.AddWithValue("@usuario", txtUsuario.Text);
                        cmdAdmin.Parameters.AddWithValue("@contraseña", txtContra.Text);

                        int esAdmin = (int)cmdAdmin.ExecuteScalar();

                        if (esAdmin > 0)
                        {
                            this.Hide();
                            MenuAdministrador menuAdmin = new MenuAdministrador(true, 0); 
                            menuAdmin.ShowDialog();
                            this.Show();
                            return;
                        }
                    }

                    // No es admin, buscar cliente
                    string consultaCliente = "SELECT ClienteID FROM Clientes WHERE Nombre = @Nombre AND Contraseña = @Contraseña";
                    using (SqlCommand cmdCliente = new SqlCommand(consultaCliente, con))
                    {
                        cmdCliente.Parameters.AddWithValue("@Nombre", txtUsuario.Text);
                        cmdCliente.Parameters.AddWithValue("@Contraseña", txtContra.Text);

                        var result = cmdCliente.ExecuteScalar();
                        if (result != null)
                        {
                            int clienteID = Convert.ToInt32(result);
                            this.Hide();
                            MenuPrincipal menu = new MenuPrincipal(clienteID, false);
                            menu.ShowDialog();
                            this.Show();
                            return;
                        }
                    }

                    MessageBox.Show("Usuario o contraseña incorrectos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al iniciar sesión: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtUsuario.Clear();
            txtContra.Clear();
            txtUsuario.Focus();
        }

        private void MostrarContra_CheckedChanged(object sender, EventArgs e)
        {
            if (MostrarContra.Checked)
                txtContra.PasswordChar = '\0';
            else
                txtContra.PasswordChar = '•';
        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Hide();
            MenuRegistro registro = new MenuRegistro();
            registro.ShowDialog();
            this.Show();
        }


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
