﻿using System;
using System.Windows.Forms;
using AbrirCuen;
using Simulacion;
using BancoApp;
using cotizadorenformsintento1;
using vercuentas;
using verprestamos;

namespace Menu
{
    public partial class MenuPrincipal : Form
    {
        private int clienteIDActual;  
        private bool esAdmin;

        public MenuPrincipal(int clienteIDActual, bool esAdmin)
        {
            InitializeComponent();
            this.clienteIDActual = clienteIDActual;
            this.esAdmin = esAdmin;
        }

        private void btnAbrirCuentas_Click(object sender, EventArgs e)
        {
            AbrirCuentas form = new AbrirCuentas(clienteIDActual, esAdmin);
            form.ShowDialog();
        }

        private void btnSimularPrestamo_Click(object sender, EventArgs e)
        {
            SimulacionPrestamos form = new SimulacionPrestamos();
            form.ShowDialog();
        }

        private void btnTransacciones_Click(object sender, EventArgs e)
        {
            Bancoapp form = new Bancoapp(esAdmin, clienteIDActual);
            form.ShowDialog();
        }


        private void btnPrestamos_Click(object sender, EventArgs e)
        {
            prestamos form = new prestamos(clienteIDActual, esAdmin);
            form.ShowDialog();
        }

        private void btnVerCuentas_Click(object sender, EventArgs e)
        {
            VerCuentas verCuentasForm = new VerCuentas(clienteIDActual, esAdmin);
            verCuentasForm.ShowDialog();
        }

        private void btnVerPrestamos_Click(object sender, EventArgs e)
        {
            VerPrestamos form = new VerPrestamos(clienteIDActual, esAdmin);
            form.ShowDialog();
        }
    }
}
