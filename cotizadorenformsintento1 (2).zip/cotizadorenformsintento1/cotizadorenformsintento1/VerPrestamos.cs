﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace verprestamos
{
    public partial class VerPrestamos : Form
    {
        private int clienteIDActual;
        private bool esAdmin;
        private DataTable prestamosTable; // Mantener tabla para no perder cambios

        public VerPrestamos(int clienteIDActual, bool esAdmin)
        {
            InitializeComponent();
            this.clienteIDActual = clienteIDActual;
            this.esAdmin = esAdmin;
            CargarPrestamos();

            if (esAdmin)
            {
                dgvPrestamos.ReadOnly = false;
                foreach (DataGridViewColumn col in dgvPrestamos.Columns)
                {
                    if (col.Name != "NombreCliente")
                        col.ReadOnly = true;
                }

                dgvPrestamos.KeyDown += DgvPrestamos_KeyDown;
            }
        }

        private void CargarPrestamos()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query;

                    if (esAdmin)
                        query = "SELECT * FROM Prestamos";
                    else
                        query = @"
                        SELECT p.*
                        FROM Prestamos p
                        INNER JOIN Clientes c ON p.ClienteID = c.ClienteID
                        WHERE c.ClienteID = @clienteIDActual";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        if (!esAdmin)
                            cmd.Parameters.AddWithValue("@clienteIDActual", clienteIDActual);

                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        prestamosTable = new DataTable();
                        adapter.Fill(prestamosTable);
                        dgvPrestamos.DataSource = prestamosTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar préstamos: " + ex.Message);
            }
        }

        private void DgvPrestamos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && dgvPrestamos.CurrentCell.ColumnIndex == dgvPrestamos.Columns["NombreCliente"].Index)
            {
                dgvPrestamos.EndEdit();

                GuardarCambioNombreCliente();

                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void GuardarCambioNombreCliente()
        {
            try
            {
                int fila = dgvPrestamos.CurrentCell.RowIndex;
                int idPrestamo = Convert.ToInt32(dgvPrestamos.Rows[fila].Cells["IdPrestamo"].Value);
                string nuevoNombre = dgvPrestamos.Rows[fila].Cells["NombreCliente"].Value?.ToString() ?? "";

                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE Prestamos SET NombreCliente = @NombreCliente WHERE IdPrestamo = @IdPrestamo";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@NombreCliente", nuevoNombre);
                        cmd.Parameters.AddWithValue("@IdPrestamo", idPrestamo);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Actualiza la tabla local para que no pierdas scroll ni selección
                prestamosTable.Rows[fila]["NombreCliente"] = nuevoNombre;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar NombreCliente: " + ex.Message);
            }
        }
    }
}


