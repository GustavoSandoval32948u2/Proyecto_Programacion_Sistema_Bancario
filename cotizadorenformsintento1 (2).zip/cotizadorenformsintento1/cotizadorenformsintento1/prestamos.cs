﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace cotizadorenformsintento1
{
    public partial class prestamos : Form
    {
        private int clienteIDActual;
        private bool esAdmin;

        public prestamos(int clienteIDActual, bool esAdmin)
        {
            InitializeComponent();
            this.clienteIDActual = clienteIDActual;
            this.esAdmin = esAdmin;

            cmbTipoInteres.Items.Add("Simple");
            cmbTipoInteres.Items.Add("Compuesto");
            cmbTipoInteres.Items.Add("Amortizable (cuota fija)");
            cmbTipoInteres.SelectedIndex = 0;

            CargarClientes();
        }

        private void label2_Click(object sender, EventArgs e) { }

        private void textBox4_TextChanged(object sender, EventArgs e) { }

        private void label1_Click(object sender, EventArgs e) { }

        private void textBox3_TextChanged(object sender, EventArgs e) { }

        private void CargarClientes()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query;
                    if (esAdmin)
                    {
                        query = "SELECT ClienteID, Nombre FROM Clientes";
                    }
                    else
                    {
                        query = "SELECT ClienteID, Nombre FROM Clientes WHERE ClienteID = @clienteID";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        if (!esAdmin)
                        {
                            cmd.Parameters.AddWithValue("@clienteID", clienteIDActual);
                        }

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            DataTable dt = new DataTable();
                            dt.Load(reader);

                            cmbNombreCliente.DisplayMember = "Nombre";
                            cmbNombreCliente.ValueMember = "ClienteID";

                            cmbNombreCliente.DataSource = dt;
                        }
                    }

                    if (!esAdmin && cmbNombreCliente.Items.Count > 0)
                    {
                        cmbNombreCliente.SelectedIndex = 0;
                        cmbNombreCliente.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los nombres de los clientes: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int clienteID = (int)cmbNombreCliente.SelectedValue;
                decimal montoSolicitado = decimal.Parse(txtMontoSolicitado.Text);
                decimal porcentajeInteres = decimal.Parse(txtPorcentajeInteres.Text) / 100;
                int numeroMeses = int.Parse(txtNumeroMeses.Text);
                DateTime fechaInicio = DateTime.Parse(txtFechaInicio.Text);

                string tipoInteres = cmbTipoInteres.SelectedItem.ToString();
                pagos.Items.Clear();

                decimal cuotaMensual = 0;

                if (tipoInteres == "Simple")
                {
                    decimal montoTotal = montoSolicitado * (1 + porcentajeInteres * numeroMeses / 12);
                    cuotaMensual = montoTotal / numeroMeses;

                    for (int i = 1; i <= numeroMeses; i++)
                    {
                        DateTime fechaPago = fechaInicio.AddMonths(i);
                        pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                    }
                }
                else if (tipoInteres == "Compuesto")
                {
                    decimal montoTotal = montoSolicitado * (decimal)Math.Pow((double)(1 + porcentajeInteres / 12), numeroMeses);
                    cuotaMensual = montoTotal / numeroMeses;

                    for (int i = 1; i <= numeroMeses; i++)
                    {
                        DateTime fechaPago = fechaInicio.AddMonths(i);
                        pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                    }
                }
                else if (tipoInteres == "Amortizable (cuota fija)")
                {
                    decimal tasaMensual = porcentajeInteres / 12;
                    cuotaMensual = montoSolicitado * (tasaMensual * (decimal)Math.Pow(1 + (double)tasaMensual, numeroMeses)) /
                                   ((decimal)Math.Pow(1 + (double)tasaMensual, numeroMeses) - 1);

                    for (int i = 1; i <= numeroMeses; i++)
                    {
                        DateTime fechaPago = fechaInicio.AddMonths(i);
                        pagos.Items.Add($"Mes {i}: {fechaPago:yyyy-MM-dd} - Cuota Total: {cuotaMensual:C}");
                    }
                }

                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO Prestamos 
                        (ClienteID, NombreCliente, MontoSolicitado, PorcentajeInteres, NumeroMeses, FechaInicio, CuotaMensual)
                        VALUES (@ClienteID, @NombreCliente, @MontoSolicitado, @PorcentajeInteres, @NumeroMeses, @FechaInicio, @CuotaMensual)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ClienteID", clienteID);
                        cmd.Parameters.AddWithValue("@NombreCliente", cmbNombreCliente.Text); 
                        cmd.Parameters.AddWithValue("@MontoSolicitado", montoSolicitado);
                        cmd.Parameters.AddWithValue("@PorcentajeInteres", porcentajeInteres * 100);
                        cmd.Parameters.AddWithValue("@NumeroMeses", numeroMeses);
                        cmd.Parameters.AddWithValue("@FechaInicio", fechaInicio);
                        cmd.Parameters.AddWithValue("@CuotaMensual", cuotaMensual);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Préstamo calculado y guardado exitosamente.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese datos válidos.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}");
            }
        }
    }
}
