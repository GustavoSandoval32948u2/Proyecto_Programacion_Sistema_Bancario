﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Logeo_Proyecto
{
    public partial class MenuRegistro : Form
    {
        public MenuRegistro()
        {
            InitializeComponent();
        }

        private void buttonRegistrar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string cedula = txtCedula.Text.Trim();
            string correo = txtCorreo.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string contra = txtContra.Text.Trim();
            string confirmar = txtConfirmar.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(cedula) ||
                string.IsNullOrEmpty(contra) || string.IsNullOrEmpty(confirmar))
            {
                MessageBox.Show("Por favor complete todos los campos obligatorios: Nombre, Cédula, Contraseña y Confirmar Contraseña.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (contra != confirmar)
            {
                MessageBox.Show("Las contraseñas no coinciden.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                string conexionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";
                using (SqlConnection conexion = new SqlConnection(conexionString))
                {
                    conexion.Open();

                    string consultaExiste = "SELECT COUNT(*) FROM Clientes WHERE Cedula = @cedula";
                    using (SqlCommand cmdExiste = new SqlCommand(consultaExiste, conexion))
                    {
                        cmdExiste.Parameters.AddWithValue("@cedula", cedula);
                        int existe = (int)cmdExiste.ExecuteScalar();
                        if (existe > 0)
                        {
                            MessageBox.Show("La cédula ya está registrada.", "Duplicado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // Insertar nuevo cliente
                    string consultaInsertar = @"INSERT INTO Clientes (Nombre, Cedula, Correo, Telefono, Contraseña)
                                               VALUES (@nombre, @cedula, @correo, @telefono, @contraseña)";
                    using (SqlCommand cmdInsertar = new SqlCommand(consultaInsertar, conexion))
                    {
                        cmdInsertar.Parameters.AddWithValue("@nombre", nombre);
                        cmdInsertar.Parameters.AddWithValue("@cedula", cedula);
                        cmdInsertar.Parameters.AddWithValue("@correo", string.IsNullOrEmpty(correo) ? (object)DBNull.Value : correo);
                        cmdInsertar.Parameters.AddWithValue("@telefono", string.IsNullOrEmpty(telefono) ? (object)DBNull.Value : telefono);
                        cmdInsertar.Parameters.AddWithValue("@contraseña", contra);

                        cmdInsertar.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Cliente registrado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar cliente:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void MostrarContra_CheckedChanged(object sender, EventArgs e)
        {
            bool mostrar = MostrarContra.Checked;
            txtContra.PasswordChar = mostrar ? '\0' : '•';
            txtConfirmar.PasswordChar = mostrar ? '\0' : '•';
        }


        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtCedula.Clear();
            txtCorreo.Clear();
            txtTelefono.Clear();
            txtContra.Clear();
            txtConfirmar.Clear();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
