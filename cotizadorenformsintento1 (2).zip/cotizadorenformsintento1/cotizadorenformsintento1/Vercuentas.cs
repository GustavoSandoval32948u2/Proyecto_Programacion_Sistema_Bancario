﻿using System;
using System.Data;
using System.Data.SqlClient;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace vercuentas
{
    public partial class VerCuentas : Form
    {
        private int clienteIDActual;   // Cambiado a int
        private bool esAdmin;

        public VerCuentas(int clienteIDActual, bool esAdmin)  // Cambiado a int
        {
            InitializeComponent();
            this.clienteIDActual = clienteIDActual;
            this.esAdmin = esAdmin;
            CargarCuentas();
        }

        private void CargarCuentas()
        {
            try
            {
                string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query;

                    if (esAdmin)
                    {
                        // Admin ve todo
                        query = @"
                        SELECT c.CuentaID, cl.Nombre, cl.Cedula, c.TipoCuenta, c.Saldo
                        FROM Cuentas c
                        INNER JOIN Clientes cl ON c.ClienteID = cl.ClienteID";
                    }
                    else
                    {
                        // Cliente solo ve sus cuentas
                        query = @"
                        SELECT c.CuentaID, cl.Nombre, cl.Cedula, c.TipoCuenta, c.Saldo
                        FROM Cuentas c
                        INNER JOIN Clientes cl ON c.ClienteID = cl.ClienteID
                        WHERE cl.ClienteID = @clienteIDActual";  // Cambiado filtro
                    }

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        if (!esAdmin)
                        {
                            cmd.Parameters.AddWithValue("@clienteIDActual", clienteIDActual);
                        }

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dgvCuentas.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar cuentas: {ex.Message}");
            }
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            CargarCuentas();
        }
    }
}
