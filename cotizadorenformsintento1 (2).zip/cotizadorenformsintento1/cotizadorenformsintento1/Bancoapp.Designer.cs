﻿namespace BancoApp
{
    partial class Bancoapp
    {

        private System.ComponentModel.IContainer components = null;

        /// <param name="disposing"
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboTipoOperacion = new System.Windows.Forms.ComboBox();
            this.txtMonto = new System.Windows.Forms.TextBox();
            this.txtCuentaOrigen = new System.Windows.Forms.TextBox();
            this.txtCuentaDestino = new System.Windows.Forms.TextBox();
            this.btnRegistrarTransaccion = new System.Windows.Forms.Button();
            this.dgvTransacciones = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacciones)).BeginInit();
            this.SuspendLayout();
            // 
            // comboTipoOperacion
            // 
            this.comboTipoOperacion.BackColor = System.Drawing.SystemColors.Info;
            this.comboTipoOperacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboTipoOperacion.Font = new System.Drawing.Font("Segoe UI Black", 12F);
            this.comboTipoOperacion.FormattingEnabled = true;
            this.comboTipoOperacion.Location = new System.Drawing.Point(137, 146);
            this.comboTipoOperacion.Name = "comboTipoOperacion";
            this.comboTipoOperacion.Size = new System.Drawing.Size(145, 40);
            this.comboTipoOperacion.TabIndex = 0;
            // 
            // txtMonto
            // 
            this.txtMonto.BackColor = System.Drawing.SystemColors.Info;
            this.txtMonto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMonto.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.txtMonto.Location = new System.Drawing.Point(634, 147);
            this.txtMonto.Name = "txtMonto";
            this.txtMonto.Size = new System.Drawing.Size(123, 38);
            this.txtMonto.TabIndex = 1;
            this.txtMonto.Text = "Monto";
            // 
            // txtCuentaOrigen
            // 
            this.txtCuentaOrigen.BackColor = System.Drawing.SystemColors.Info;
            this.txtCuentaOrigen.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaOrigen.Location = new System.Drawing.Point(827, 149);
            this.txtCuentaOrigen.Name = "txtCuentaOrigen";
            this.txtCuentaOrigen.Size = new System.Drawing.Size(172, 39);
            this.txtCuentaOrigen.TabIndex = 2;
            this.txtCuentaOrigen.Text = "Cuenta origen";
            // 
            // txtCuentaDestino
            // 
            this.txtCuentaDestino.BackColor = System.Drawing.SystemColors.Info;
            this.txtCuentaDestino.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCuentaDestino.Location = new System.Drawing.Point(374, 147);
            this.txtCuentaDestino.Name = "txtCuentaDestino";
            this.txtCuentaDestino.Size = new System.Drawing.Size(192, 39);
            this.txtCuentaDestino.TabIndex = 3;
            this.txtCuentaDestino.Text = "Cuenta destino";
            // 
            // btnRegistrarTransaccion
            // 
            this.btnRegistrarTransaccion.BackColor = System.Drawing.SystemColors.Info;
            this.btnRegistrarTransaccion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrarTransaccion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarTransaccion.Location = new System.Drawing.Point(493, 216);
            this.btnRegistrarTransaccion.Name = "btnRegistrarTransaccion";
            this.btnRegistrarTransaccion.Size = new System.Drawing.Size(210, 77);
            this.btnRegistrarTransaccion.TabIndex = 4;
            this.btnRegistrarTransaccion.Text = "Registrar Transacción";
            this.btnRegistrarTransaccion.UseVisualStyleBackColor = false;
            this.btnRegistrarTransaccion.Click += new System.EventHandler(this.btnRegistrarTransaccion_Click);
            // 
            // dgvTransacciones
            // 
            this.dgvTransacciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTransacciones.Location = new System.Drawing.Point(137, 333);
            this.dgvTransacciones.Name = "dgvTransacciones";
            this.dgvTransacciones.RowHeadersWidth = 62;
            this.dgvTransacciones.RowTemplate.Height = 28;
            this.dgvTransacciones.Size = new System.Drawing.Size(903, 247);
            this.dgvTransacciones.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(465, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 45);
            this.label1.TabIndex = 6;
            this.label1.Text = "TRANSACCIONES";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(402, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(400, 28);
            this.label2.TabIndex = 7;
            this.label2.Text = "Realice Retiros, Depositos y Transferencias ";
            // 
            // Bancoapp
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1191, 607);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvTransacciones);
            this.Controls.Add(this.btnRegistrarTransaccion);
            this.Controls.Add(this.txtCuentaDestino);
            this.Controls.Add(this.txtCuentaOrigen);
            this.Controls.Add(this.txtMonto);
            this.Controls.Add(this.comboTipoOperacion);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Bancoapp";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboTipoOperacion;
        private System.Windows.Forms.TextBox txtMonto;
        private System.Windows.Forms.TextBox txtCuentaOrigen;
        private System.Windows.Forms.TextBox txtCuentaDestino;
        private System.Windows.Forms.Button btnRegistrarTransaccion;
        private System.Windows.Forms.DataGridView dgvTransacciones;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
