﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AbrirCuen
{
    public partial class AbrirCuentas : Form
    {
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

        private int clienteIDActual;
        private bool esAdmin;

        // Constructor adaptado para recibir filtro
        public AbrirCuentas(int clienteIDActual, bool esAdmin)
        {
            InitializeComponent();
            this.clienteIDActual = clienteIDActual;
            this.esAdmin = esAdmin;
        }

        private void AbrirCuentas_Load(object sender, EventArgs e)
        {
            comboBoxTipoCuenta.Items.Add("Ahorros");
            comboBoxTipoCuenta.Items.Add("Corriente");

            using (SqlConnection conexion = new SqlConnection(connectionString))
            {
                conexion.Open();

                string query;
                if (esAdmin)
                {
                    query = "SELECT ClienteID, Nombre FROM Clientes";
                }
                else
                {
                    query = "SELECT ClienteID, Nombre FROM Clientes WHERE ClienteID = @clienteID";
                }

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    if (!esAdmin)
                    {
                        cmd.Parameters.AddWithValue("@clienteID", clienteIDActual);
                    }

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        var clientes = new List<KeyValuePair<int, string>>();
                        while (reader.Read())
                        {
                            clientes.Add(new KeyValuePair<int, string>(
                                reader.GetInt32(0),
                                reader.GetString(1)
                            ));
                        }

                        comboBoxClientes.DataSource = clientes;
                        comboBoxClientes.DisplayMember = "Value";
                        comboBoxClientes.ValueMember = "Key";
                        comboBoxClientes.SelectedIndex = -1;
                    }
                }
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBoxClientes.SelectedIndex == -1 || comboBoxTipoCuenta.SelectedIndex == -1)
                {
                    MessageBox.Show("Por favor, selecciona un cliente y un tipo de cuenta.");
                    return;
                }

                int clienteId = (int)comboBoxClientes.SelectedValue;
                string tipoCuenta = comboBoxTipoCuenta.SelectedItem.ToString();
                decimal saldoInicial = decimal.Parse(textBoxSaldoInicial.Text);

                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();

                    string validarQuery = "SELECT COUNT(*) FROM Cuentas WHERE ClienteID = @clienteId AND TipoCuenta = @tipoCuenta";
                    using (SqlCommand cmdValidar = new SqlCommand(validarQuery, conexion))
                    {
                        cmdValidar.Parameters.AddWithValue("@clienteId", clienteId);
                        cmdValidar.Parameters.AddWithValue("@tipoCuenta", tipoCuenta);

                        int count = (int)cmdValidar.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("El cliente ya tiene una cuenta de este tipo.");
                            return;
                        }
                    }

                    string query = "INSERT INTO Cuentas (ClienteID, TipoCuenta, Saldo) VALUES (@clienteId, @tipoCuenta, @saldo)";
                    using (SqlCommand cmd = new SqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@clienteId", clienteId);
                        cmd.Parameters.AddWithValue("@tipoCuenta", tipoCuenta);
                        cmd.Parameters.AddWithValue("@saldo", saldoInicial);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Cuenta creada exitosamente.");
                LimpiarCampos();
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingresa un saldo inicial válido.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear la cuenta: " + ex.Message);
            }
        }


        private void LimpiarCampos()
        {
            comboBoxClientes.SelectedIndex = -1;
            comboBoxTipoCuenta.SelectedIndex = -1;
            textBoxSaldoInicial.Text = "";
        }
    }
}
