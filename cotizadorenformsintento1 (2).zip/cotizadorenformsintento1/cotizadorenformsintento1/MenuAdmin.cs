﻿using AbrirCuen;
using BancoApp;
using editarcliente;
using Gestion;
using System.Windows.Forms;
using System;
using verclientes;
using vercuentas;
using verprestamos;

namespace menuadmin
{
    public partial class MenuAdministrador : Form
    {
        private bool esAdmin;
        private int clienteIDActual;

        public MenuAdministrador(bool esAdmin, int clienteIDActual)
        {
            InitializeComponent();
            this.esAdmin = esAdmin;
            this.clienteIDActual = clienteIDActual;
            
        }

        private void btnVerClientes_Click(object sender, EventArgs e)
        {
            VerClientes verClientes = new VerClientes();
            verClientes.Show();
        }

        private void btnVerCuentas_Click(object sender, EventArgs e)
        {
            VerCuentas verCuentasForm = new VerCuentas(clienteIDActual, esAdmin);
            verCuentasForm.ShowDialog();
        }

        private void btnGestionCuentas_Click(object sender, EventArgs e)
        {
            GestionCuentas abrirCuentaForm = new GestionCuentas();
            abrirCuentaForm.ShowDialog();
        }

        private void btnVerPrestamos_Click(object sender, EventArgs e)
        {
            VerPrestamos form = new VerPrestamos(clienteIDActual, esAdmin);
            form.ShowDialog();
        }

        private void btnAbrirCuentas_Click(object sender, EventArgs e)
        {
            AbrirCuentas form = new AbrirCuentas(clienteIDActual, esAdmin);
            form.ShowDialog();
        }

        private void btnGestionClientes_Click(object sender, EventArgs e)
        {
            GestionClientes gestionClientesForm = new GestionClientes();
            gestionClientesForm.ShowDialog();
        }

        private void btnTransacciones_Click(object sender, EventArgs e)
        {
            Bancoapp form = new Bancoapp(esAdmin, clienteIDActual);
            form.ShowDialog();
        }

    }
}
