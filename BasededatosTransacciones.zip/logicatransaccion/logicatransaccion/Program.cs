﻿using System;
using System.Windows.Forms;

namespace BancoApp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Habilitar estilos visuales en la aplicación.
            Application.EnableVisualStyles();
            // Habilitar la compatibilidad de texto enriquecido.
            Application.SetCompatibleTextRenderingDefault(false);
            // Ejecutar el formulario principal de la aplicación.
            Application.Run(new Form1());
        }
    }
}
