﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BancoApp
{
    public partial class Form1 : Form
    {
        private string conexion = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bancotransacciones;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            CargarTransacciones();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Cargar las opciones del ComboBox al iniciar
            comboTipoOperacion.Items.Clear();
            comboTipoOperacion.Items.Add("Deposito");
            comboTipoOperacion.Items.Add("Retiro");
            comboTipoOperacion.Items.Add("Transferencia");
            comboTipoOperacion.SelectedIndex = 0;  // Selecciona "Deposito" por defecto
        }

        private void btnRegistrarTransaccion_Click(object sender, EventArgs e)
        {
            // Validación de entrada
            if (string.IsNullOrEmpty(txtMonto.Text) || !decimal.TryParse(txtMonto.Text, out decimal monto) || monto <= 0)
            {
                MessageBox.Show("Por favor, ingrese un monto válido.");
                return;
            }

            if (string.IsNullOrEmpty(txtCuentaOrigen.Text) && comboTipoOperacion.Text != "Deposito")
            {
                MessageBox.Show("La cuenta origen es obligatoria para Retiro y Transferencia.");
                return;
            }

            // Asignación de valores
            string tipoOperacion = comboTipoOperacion.Text;
            int? cuentaOrigen = string.IsNullOrWhiteSpace(txtCuentaOrigen.Text) ? (int?)null : int.Parse(txtCuentaOrigen.Text);
            int? cuentaDestino = string.IsNullOrWhiteSpace(txtCuentaDestino.Text) ? (int?)null : int.Parse(txtCuentaDestino.Text);

            try
            {
                // Abrir conexión y registrar transacción
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    conn.Open();
                    string query = @"INSERT INTO Transacciones (IdCuentaOrigen, IdCuentaDestino, TipoOperacion, Monto)
                                     VALUES (@origen, @destino, @tipo, @monto)";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@origen", (object)cuentaOrigen ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@destino", (object)cuentaDestino ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@tipo", tipoOperacion);
                    cmd.Parameters.AddWithValue("@monto", monto);

                    cmd.ExecuteNonQuery();  // Ejecutar la consulta
                    MessageBox.Show("Transacción registrada correctamente.");
                }

                // Recargar transacciones después de insertar una nueva
                CargarTransacciones();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar transacción:\n" + ex.Message);
            }
        }

        private void CargarTransacciones()
        {
            try
            {
                // Abrir conexión y cargar las transacciones existentes
                using (SqlConnection conn = new SqlConnection(conexion))
                {
                    conn.Open();
                    string query = "SELECT * FROM Transacciones";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvTransacciones.DataSource = dt;  // Mostrar las transacciones en el DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar transacciones:\n" + ex.Message);
            }
        }
    }
}
